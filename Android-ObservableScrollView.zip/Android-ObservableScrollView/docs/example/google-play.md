# Download from Google Play

Click the following link to download the example app from Google Play.

[![Get it on Google Play](https://developer.android.com/images/brand/en_generic_rgb_wo_45.png)](https://play.google.com/store/apps/details?id=com.github.ksoichiro.android.observablescrollview.samples2)

Please note that the app on the Play Store is not always the latest version.  
If you'd like to install the latest one,

* install it manually.
* or if you are a wercker user, you can download the latest build artifact from wercker.

[Next: Download from wercker &raquo;](../../docs/example/wercker.md)
