# Sliding up pattern

This topic describes how to slide a panel from the bottom like Google's "Map" app,
which are implemented in the following examples.

* SlidingUpBaseActivity
* SlidingUpGridViewActivity
* SlidingUpListViewActivity
* SlidingUpRecyclerViewActivity
* SlidingUpScrollViewActivity
* SlidingUpWebViewActivity

---

Coming soon...

[Next: ViewPager pattern &raquo;](../../docs/advanced/viewpager.md)
